function Bella_Coola() {
	document.FormName.Location.value = 'BCGH PO Box 200, McKay St, Bella Coola, V0T 1C0; Ph 250-799-5311 ext 209; Fax 250-799-5350';
	document.FormName.HospitalSite.value = 'Bella Coola';
	}
function LGH_XR() {
	document.FormName.Location.value = 'LGH 231 East 15th St, North Vancouver, V7L 2L7; Ph 604-984-5775; Fax 604-984-5777 (XR)';
	document.FormName.HospitalSite.value = 'Lions Gate Hospital';
	}
function LGH_CT() {
	document.FormName.Location.value = 'LGH 231 East 15th St, North Vancouver, V7L 2L7; Ph 604-984-5776; Fax 604-984-5885 (CT)';
	document.FormName.HospitalSite.value = 'Lions Gate Hospital';
	}
function LGH_MRI() {
	document.FormName.Location.value = 'LGH 231 East 15th St, North Vancouver, V7L 2L7; Ph 604-984-3792; Fax 604-984-5885 (MRI)';
	document.FormName.HospitalSite.value = 'Lions Gate Hospital';
	}
function LGH_NucMed_BMD() {
	document.FormName.Location.value = 'LGH 231 East 15th St, North Vancouver, V7L 2L7; Ph 604-984-5780; Fax 604-984-5781 (NucMed/BMD)';
	document.FormName.HospitalSite.value = 'Lions Gate Hospital';
	}
function LGH_US_Echo() {
	document.FormName.Location.value = 'LGH 231 East 15th St, North Vancouver, V7L 2L7; Ph 604-984-5721; Fax 604-984-5716 (US/Echo)';
	document.FormName.HospitalSite.value = 'Lions Gate Hospital';
	}
function LGH_SMP() {
	document.FormName.Location.value = 'LGH 231 East 15th St, North Vancouver, V7L 2L7; Ph 604-903-3860; Fax 604-903-3780 (SMP)';
	document.FormName.HospitalSite.value = 'Lions Gate Hospital';
	}
function Pemberton() {
	document.FormName.Location.value = 'Pemberton Health Ctr 1403 Portage Rd, Pemberton, V0N 2L0; Ph 604-894-6939 ext 227; Fax 604-903-3780';
	document.FormName.HospitalSite.value = 'Pemberton';
	}
function PRGH() {
	document.FormName.Location.value = 'Powell River General Hospital 5000 Joyce Ave, Powell River, V8A 5R3; Ph 604-485-3282; Fax 604-485-3254';
	document.FormName.HospitalSite.value = 'Powell River';
	}
function Richmond_XR_CT_etc() {
	document.FormName.Location.value = '7000 Westminster Hwy, Richmond, V6X 1A2; Ph 604-244-5104; Fax 604-244-5232 (XR/CT/NucMed/US)';
	document.FormName.HospitalSite.value = 'Richmond Hospital';
	}
function Richmond_Mammo() {
	document.FormName.Location.value = '7000 Westminster Hwy, Richmond, V6X 1A2; Ph 604-278-9711 ext 4243; Fax 604-244-5232 (Diag Mammo)';
	document.FormName.HospitalSite.value = 'Richmond Hospital';
	}
function Bella_Bella() {
	document.FormName.Location.value = 'RW Large Memorial Hospital 88 Waglisa St, Bella Bella, V0T 1Z0; Ph 250-957-2314 ext 234; Fax 250-957-2702';
	document.FormName.HospitalSite.value = 'Bella Bella';
	}
function Squamish() {
	document.FormName.Location.value = 'Squamish General Hospital 38140 Behrner, Squamish, V0N 3G0; Ph 604-892-6025; Fax 604-892-6072';
	document.FormName.HospitalSite.value = 'Squamish';
	}
function Sechelt() {
	document.FormName.Location.value = "St. Mary's Hospital 5544 Sunshine Coast Hwy, Sechelt, V0N 3A0; Ph 604-885-8608; Fax 604-885-8652";
	document.FormName.HospitalSite.value = 'Sechelt';
	}
function Sechelt_CT() {
	document.FormName.Location.value = "St. Mary's Hospital 5544 Sunshine Coast Hwy, Sechelt, V0N 3A0; Ph 604-885-8622; Fax 604-885-8612 (CT)";
	document.FormName.HospitalSite.value = 'Sechelt - CT';
	}
function UBC_CT_XR_Angio_US() {
	document.FormName.Location.value = 'UBC 2211 Wesbrook Mall, Vancouver, V6T 2B6; Ph 604-822-7080; Fax 604-822-9701 (CT/XR/Angio/US/Echo)';
	document.FormName.HospitalSite.value = 'UBC - CT/XR/etc';
	}
function UBC_NucMed() {
	document.FormName.Location.value = 'UBC 2211 Wesbrook Mall, Vancouver, V6T 2B6; Ph 604-822-7267; Fax 604-875-5009 (NucMed)';
	document.FormName.HospitalSite.value = 'UBC - NucMed';
	}
function VGH_Angio_CT() {
	document.FormName.Location.value = 'VGH 899 West 12th Ave, Vancouver, V5Z 1M9; Ph 604-875-4366; Fax 604-875-5453 (Angio/CT)';
	document.FormName.HospitalSite.value = 'VGH - Angio/CT';
	}
function VGH_GI_GU_litho() {
	document.FormName.Location.value = 'VGH 899 West 12th Ave, Vancouver, V5Z 1M9; Ph 604-875-4770; Fax 604-875-4228 (GI/GU/Litho)';
	document.FormName.HospitalSite.value = 'VGH - GI/GU/litho';
	}
function VGH_Diamond() {
	document.FormName.Location.value = 'Diamond Health Care Ctr, 2775 Laurel St, Vancouver, V5Z 1M9; Ph 604-875-4074; Fax 604-875-4071';
	document.FormName.HospitalSite.value = 'VGH Diamond Ctr';
	}
function VGH_NucMed_BMD() {
	document.FormName.Location.value = 'VGH 899 West 12th Ave, Vancouver, V5Z 1M9; Ph 604-875-4611; Fax 604-875-5009 (NucMed/BMD)';
	document.FormName.HospitalSite.value = 'VGH - NucMed/BMD';
	}
function VGH_US() {
	document.FormName.Location.value = 'VGH 899 West 12th Ave, Vancouver, V5Z 1M9; Ph 604-875-4340; Fax 604-875-4228 (US)';
	document.FormName.HospitalSite.value = 'VGH - US';
	}
function VGH_XR() {
	document.FormName.Location.value = 'VGH 899 West 12th Ave, Vancouver, V5Z 1M9; Ph 604-875-4287; Fax 604-875-5831 (XR)';
	document.FormName.HospitalSite.value = 'VGH - XR';
	}
function Whistler() {
	document.FormName.Location.value = 'Whistler Health Ctr 4380 Lorimer Rd, Whistler, V0N 1B5; Ph 604-932-4911 ext 2228; Fax 604-932-5326';
	document.FormName.HospitalSite.value = 'Whistler';
	}
